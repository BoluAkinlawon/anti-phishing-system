<?php
$connection = mysqli_connect("localhost","root","");
$db = mysql_select_db($connection, "anti_phishing");
?>