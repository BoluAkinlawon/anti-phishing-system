<html>
<head>
<title>Facial Recognition software</title>
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type" />
     <meta name="viewport" content="width=100% height =100%,initial-scale=0.7,maximum-scale=1.0,user-scalable=no">
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
     <meta name="HandheldFriendly" content="true">

</head>
<body style ="background-color:green; font-family:verdana;">
<center>
<fieldset style ="width:80%; height:590px; background-color:lightblue; border-radius: 10px;">
<div style ="background:lightgreen; height: 45px; width: 50%;">
<a href ="index.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Home</a>
  
  
  <a href ="user/register.php" style ="background-color: blue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;"> Register</a>
  
  <a href ="user/dashboard.php" style ="background-color: green;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Login</a></li>
    </ul>
	
</div>
<br><br><br>
<p align ="center"><b>ANTI-PHISHING SOFTWARE</b></p>
<p>This is an anti-phishing system </p>


<p style ="background:cyan;"><i>You can type in the website URL here to verify(in the format www.example.com)</i></p>
<form action ="" method ="post">
<input name ="site" type ="text" style ="height:50px; width:260px; border-radius:15px;"></input>
<button style ="height:50px; width:100px; border-radius:15px; " name ="search" type ="submit">Search</button>
</form>
<?php
include "includes/config.php";

if (isset($_POST["search"])){
	$site = $_POST['site'];
	
	$query = "SELECT wrong_site from phished where wrong_site ='$site'";
	$query_run = mysqli_query($connection, $query);
	
	$query2 = "SELECT correct_site from phished where correct_site ='$site'";
	$query_run2 = mysqli_query($connection, $query2);
	
	if($query_run-> num_rows>0){
		echo "This is a phishing site";
	}
	else if($query_run2-> num_rows>0){
		echo "This is a legitimate site";
	}
	else{
		echo "There is no information on this yet.";
	}
	
}

?>
</fieldset>
</center>

</body>
</html>