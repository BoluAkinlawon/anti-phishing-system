create table facial_recog and import the anti_phishing.sql file
for admin, username:admin, password admin