<?php
include "includes/config.php";
if(isset($_POST["submit"])){
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	$query = "SELECT username, password from user WHERE username = '$username' AND password ='$password'";
	$query_run =mysqli_query($connection, $query);
	
	if($query_run-> num_rows>0){
		session_start();
		$_SESSION['username'] = $username;
		header ("location:dashboard.php");
	}
	else{
		echo "<a style ='background:red;' href ='register.php'>"."Please register first"."</a>";
	}
}

?>

<html>
<head>
<title>Anti-Phishing software</title>
<meta content="text/html; charset=ISO-8859-1" http-equiv="content-type" />
     <meta name="viewport" content="width=100% height =100%,initial-scale=0.7,maximum-scale=1.0,user-scalable=no">
     <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
     <meta name="HandheldFriendly" content="true">

</head>
<body style ="background-color:green; font-family:verdana;">
<center>
<fieldset style ="width:80%; height:620px; background-color:lightblue; border-radius: 10px;">
<div style ="background:lightgreen; height: 45px; width: 50%;">
<a href ="../index.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Home</a>
  
  
  <a href ="register.php" style ="background-color: blue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;"> Register</a>
  
  <a href ="dashboard.php" style ="background-color: green;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Login</a></li>
    </ul>
</div>
<br><br><br>
<p align ="center"><b>ANTI-PHISHING SOFTWARE</b></p>
<p>This is an anti-phishing system </p>

<center>
<form action ="" method ="post">
 <fieldset style ="height:175px; width:20%; border-radius:10px;">
 <input type ="text" name ="username" placeholder ="Username" style ="height: 45px; width: 145px; text-align:center; border-radius:15px;"></input><br>
 <br>
 <label for "password">
 <input type ="password" name ="password" placeholder ="Password" style ="height: 45px; width: 145px; text-align:center; border-radius:15px;"></input><br>
 <br>
 <label for "submit">
 <input type ="submit" name ="submit" style ="height: 35px; width: 100px; text-align:center; border-radius:15px;"></input><br>
 </form>
 
 
 
 </fieldset>
</center>

</fieldset>
</center>
</body>
</html>