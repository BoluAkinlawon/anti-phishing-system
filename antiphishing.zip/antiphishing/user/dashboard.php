<?php
include "includes/config.php";
session_start();
if(!isset($_SESSION['username'])){
	
	header("location:login.php");
	
}

?>


<!DOCTYPE html>
<html>
<head>
    <title>Anti-Phishing Software</title>
    
</head>
<body style ="background-color:lightgreen; font-family:verdana;">
<center>
<br>
<fieldset style ="width:80%; height:120px; background-color:lightblue; border-radius: 10px;">
<br>
<div style ="background:lightgreen; height: 45px; width: 50%;">
<a href ="../index.php" style ="background-color: lightblue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Home</a>
  
  
  <a href ="user/register.php" style ="background-color: blue;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;"> Register</a>
  
  <a href ="user/dashboard.php" style ="background-color: green;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Login</a></li>
  <br>
  
  <?php
if(isset($_POST['logout'])){
	session_destroy();
	header("location:login.php");
}
  ?>
  <br>
  <form action ="" method ="post"> 
    <button type ="submit" name ="logout" style ="background-color: green;
  color: white;padding: 10px 20px; text-align: center;text-decoration: none;
  display: inline-block;">Log Out</button></li>
  </form>
  
  
    </ul>
</div>
<br><br><br>
<p align ="center"><b>ANTI-PHISHING SOFTWARE<b></p>
<p></p>
<p></p>
Report a fake site
<br>
<i>Enter URL:</i>
<BR>
<form action ="" method ="post">
<input type ="text" style ="height:50px; width:260px; border-radius:15px;"></input>
<button style ="height:50px; width:100px; border-radius:15px;" name ="report" type ="submit">Report</button>
</form>


<?php

?>
<head>
    <title>Anti-Phishing Software</title>
    
</head>
<body>
</body>
</html>